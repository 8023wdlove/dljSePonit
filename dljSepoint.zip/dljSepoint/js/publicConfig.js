


 //图片的左 minLon，右 maxLon，上 maxLat， 下 minLat的坐标
 const publicOptions = {
    '1': {
       name: 'pingandalao',
       coord:{
           maxLon: '121.393135',
           minLon: '121.380113',
           maxLat: '37.603998',
           minLat: '37.594018',
       }
    },
}
